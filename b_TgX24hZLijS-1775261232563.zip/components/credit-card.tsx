'use client'

import { Credit } from '@/lib/types'
import { formatCurrency, daysUntilDate } from '@/lib/store'
import { SwipeableCard } from './swipeable-card'
import { CreditCard as CreditCardIcon, Clock, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'

interface CreditCardProps {
  credit: Credit
  onEdit: () => void
  onDelete: () => void
}

export function CreditCardItem({ credit, onEdit, onDelete }: CreditCardProps) {
  const daysLeft = daysUntilDate(credit.dueDate)
  const isOverdue = daysLeft < 0
  const isUrgent = daysLeft <= 3 && daysLeft >= 0
  const usagePercent = Math.round((credit.debt / credit.limit) * 100)
  
  return (
    <SwipeableCard onDelete={onDelete} onClick={onEdit}>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center",
              isOverdue ? "bg-destructive/10 text-destructive" :
              isUrgent ? "bg-warning/10 text-warning" :
              "bg-primary/10 text-primary"
            )}>
              {isOverdue ? <AlertTriangle size={22} /> : <CreditCardIcon size={22} />}
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{credit.name}</h3>
              <p className="text-xs text-muted-foreground">
                Лимит: {formatCurrency(credit.limit)}
              </p>
            </div>
          </div>
          
          <div className="text-right">
            <p className="text-lg font-bold text-destructive tabular-nums">
              -{formatCurrency(credit.debt)}
            </p>
            <div className={cn(
              "flex items-center gap-1 text-xs",
              isOverdue ? "text-destructive" :
              isUrgent ? "text-warning" :
              "text-muted-foreground"
            )}>
              <Clock size={12} />
              {isOverdue ? `Просрочено ${Math.abs(daysLeft)} дн.` :
               daysLeft === 0 ? 'Сегодня' :
               daysLeft === 1 ? 'Завтра' :
               `${daysLeft} дн.`}
            </div>
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="space-y-1">
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className={cn(
                "h-full rounded-full transition-all duration-500",
                usagePercent > 80 ? "bg-destructive" :
                usagePercent > 50 ? "bg-warning" :
                "bg-accent"
              )}
              style={{ width: `${Math.min(usagePercent, 100)}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Использовано {usagePercent}%</span>
            <span>Свободно: {formatCurrency(credit.limit - credit.debt)}</span>
          </div>
        </div>
      </div>
    </SwipeableCard>
  )
}
