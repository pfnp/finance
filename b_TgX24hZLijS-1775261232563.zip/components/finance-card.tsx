'use client'

import { Finance } from '@/lib/types'
import { formatCurrency, getFinanceTypeLabel } from '@/lib/store'
import { SwipeableCard } from './swipeable-card'
import { Banknote, CreditCard, TrendingUp, FileText } from 'lucide-react'
import { cn } from '@/lib/utils'

interface FinanceCardProps {
  finance: Finance
  onEdit: () => void
  onDelete: () => void
}

const typeIcons = {
  cash: Banknote,
  card: CreditCard,
  investments: TrendingUp,
  debt: FileText,
}

const typeColors = {
  cash: 'bg-accent/10 text-accent',
  card: 'bg-primary/10 text-primary',
  investments: 'bg-chart-2/20 text-chart-2',
  debt: 'bg-destructive/10 text-destructive',
}

export function FinanceCard({ finance, onEdit, onDelete }: FinanceCardProps) {
  const Icon = typeIcons[finance.type]
  
  return (
    <SwipeableCard onDelete={onDelete} onClick={onEdit}>
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-12 h-12 rounded-2xl flex items-center justify-center",
          typeColors[finance.type]
        )}>
          <Icon size={22} />
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground truncate">
            {finance.name}
          </h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
              {getFinanceTypeLabel(finance.type)}
            </span>
            {finance.monthlyIncome && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-accent/10 text-accent">
                +{formatCurrency(finance.monthlyIncome)}/мес
              </span>
            )}
          </div>
        </div>
        
        <p className={cn(
          "text-lg font-bold tabular-nums",
          finance.type === 'debt' ? "text-destructive" : "text-foreground"
        )}>
          {finance.type === 'debt' ? '-' : ''}{formatCurrency(finance.amount)}
        </p>
      </div>
    </SwipeableCard>
  )
}
