'use client'

import { useState, useEffect, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Finance, Credit, Subscription, TabType } from '@/lib/types'
import {
  loadFinances, loadCredits, loadSubscriptions,
  saveFinances, saveCredits, saveSubscriptions,
  sortFinances, sortCredits, sortSubscriptions,
} from '@/lib/store'
import { TabBar } from './tab-bar'
import { SectionHeader } from './section-header'
import { TotalCard } from './total-card'
import { FinanceCard } from './finance-card'
import { CreditCardItem } from './credit-card'
import { SubscriptionCard } from './subscription-card'
import { AddEditModal } from './add-edit-modal'
import { ThemeProvider } from './theme-provider'

function FinanceAppContent() {
  const [activeTab, setActiveTab] = useState<TabType>('finances')
  const [finances, setFinances] = useState<Finance[]>([])
  const [credits, setCredits] = useState<Credit[]>([])
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([])
  const [mounted, setMounted] = useState(false)
  
  // Modal state
  const [modalOpen, setModalOpen] = useState(false)
  const [editingItem, setEditingItem] = useState<Finance | Credit | Subscription | null>(null)

  // Load data on mount
  useEffect(() => {
    setMounted(true)
    setFinances(loadFinances())
    setCredits(loadCredits())
    setSubscriptions(loadSubscriptions())
  }, [])

  // Save data when changed
  useEffect(() => {
    if (mounted) {
      saveFinances(finances)
    }
  }, [finances, mounted])

  useEffect(() => {
    if (mounted) {
      saveCredits(credits)
    }
  }, [credits, mounted])

  useEffect(() => {
    if (mounted) {
      saveSubscriptions(subscriptions)
    }
  }, [subscriptions, mounted])

  // Sorted data
  const sortedFinances = useMemo(() => sortFinances(finances), [finances])
  const sortedCredits = useMemo(() => sortCredits(credits), [credits])
  const sortedSubscriptions = useMemo(() => sortSubscriptions(subscriptions), [subscriptions])

  // Totals
  const financeTotals = useMemo(() => {
    let total = 0
    let monthlyIncome = 0
    finances.forEach(f => {
      if (f.type === 'debt') total -= f.amount
      else total += f.amount
      if (f.type === 'investments' && f.monthlyIncome) {
        monthlyIncome += f.monthlyIncome
      }
    })
    return { total, monthlyIncome }
  }, [finances])

  const creditTotals = useMemo(() => {
    let totalDebt = 0
    let totalRemaining = 0
    credits.forEach(c => {
      totalDebt += c.debt
      totalRemaining += (c.limit - c.debt)
    })
    return { totalDebt, totalRemaining }
  }, [credits])

  const subscriptionTotal = useMemo(() => {
    return subscriptions.reduce((sum, s) => sum + s.amount, 0)
  }, [subscriptions])

  // Handlers
  const handleAdd = () => {
    setEditingItem(null)
    setModalOpen(true)
  }

  const handleEdit = (item: Finance | Credit | Subscription) => {
    setEditingItem(item)
    setModalOpen(true)
  }

  const handleSave = (data: Finance | Credit | Subscription) => {
    if (activeTab === 'finances') {
      const f = data as Finance
      if (editingItem) {
        setFinances(prev => prev.map(item => item.id === f.id ? f : item))
      } else {
        setFinances(prev => [...prev, f])
      }
    } else if (activeTab === 'credits') {
      const c = data as Credit
      if (editingItem) {
        setCredits(prev => prev.map(item => item.id === c.id ? c : item))
      } else {
        setCredits(prev => [...prev, c])
      }
    } else {
      const s = data as Subscription
      if (editingItem) {
        setSubscriptions(prev => prev.map(item => item.id === s.id ? s : item))
      } else {
        setSubscriptions(prev => [...prev, s])
      }
    }
    setModalOpen(false)
    setEditingItem(null)
  }

  const handleDelete = (id: string) => {
    if (activeTab === 'finances') {
      setFinances(prev => prev.filter(f => f.id !== id))
    } else if (activeTab === 'credits') {
      setCredits(prev => prev.filter(c => c.id !== id))
    } else {
      setSubscriptions(prev => prev.filter(s => s.id !== id))
    }
  }

  const sectionTitle = activeTab === 'finances' ? 'Финансы' : 
                       activeTab === 'credits' ? 'Кредитки' : 'Расходы'

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background safe-area-top pb-24">
      <div className="max-w-lg mx-auto px-4 pt-4">
        <SectionHeader title={sectionTitle} onAdd={handleAdd} />

        <AnimatePresence mode="wait">
          {activeTab === 'finances' && (
            <motion.div
              key="finances"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              {/* Finance totals */}
              <div className="flex gap-3 mb-6">
                <TotalCard 
                  label="Общий баланс" 
                  amount={financeTotals.total}
                  variant={financeTotals.total >= 0 ? 'success' : 'danger'}
                  trend={financeTotals.total >= 0 ? 'up' : 'down'}
                />
                <TotalCard 
                  label="Доход в месяц" 
                  amount={financeTotals.monthlyIncome}
                  variant="success"
                />
              </div>

              {/* Finance cards */}
              <div className="space-y-3">
                {sortedFinances.map((finance, index) => (
                  <motion.div
                    key={finance.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <FinanceCard
                      finance={finance}
                      onEdit={() => handleEdit(finance)}
                      onDelete={() => handleDelete(finance.id)}
                    />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'credits' && (
            <motion.div
              key="credits"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              {/* Credit totals */}
              <div className="flex gap-3 mb-6">
                <TotalCard 
                  label="Общий долг" 
                  amount={creditTotals.totalDebt}
                  variant="danger"
                  trend="down"
                />
                <TotalCard 
                  label="Доступно" 
                  amount={creditTotals.totalRemaining}
                  variant="success"
                />
              </div>

              {/* Credit cards */}
              <div className="space-y-3">
                {sortedCredits.map((credit, index) => (
                  <motion.div
                    key={credit.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <CreditCardItem
                      credit={credit}
                      onEdit={() => handleEdit(credit)}
                      onDelete={() => handleDelete(credit.id)}
                    />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'subscriptions' && (
            <motion.div
              key="subscriptions"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              {/* Subscription total */}
              <div className="mb-6">
                <TotalCard 
                  label="Расходов в месяц" 
                  amount={subscriptionTotal}
                  className="w-full"
                />
              </div>

              {/* Subscription cards */}
              <div className="space-y-3">
                {sortedSubscriptions.map((subscription, index) => (
                  <motion.div
                    key={subscription.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <SubscriptionCard
                      subscription={subscription}
                      onEdit={() => handleEdit(subscription)}
                      onDelete={() => handleDelete(subscription.id)}
                    />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <AddEditModal
        isOpen={modalOpen}
        onClose={() => {
          setModalOpen(false)
          setEditingItem(null)
        }}
        onSave={handleSave}
        type={activeTab}
        item={editingItem}
      />
    </div>
  )
}

export function FinanceApp() {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
    >
      <FinanceAppContent />
    </ThemeProvider>
  )
}
