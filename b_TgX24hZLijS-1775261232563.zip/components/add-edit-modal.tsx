'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X } from 'lucide-react'
import { Finance, Credit, Subscription, TabType } from '@/lib/types'
import { cn } from '@/lib/utils'

interface ModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (data: Finance | Credit | Subscription) => void
  type: TabType
  item?: Finance | Credit | Subscription | null
}

export function AddEditModal({ isOpen, onClose, onSave, type, item }: ModalProps) {
  const isEdit = !!item
  const title = isEdit 
    ? type === 'finances' ? 'Редактировать' : type === 'credits' ? 'Редактировать карту' : 'Редактировать расход'
    : type === 'finances' ? 'Новая запись' : type === 'credits' ? 'Новая карта' : 'Новый расход'

  // Finance fields
  const [name, setName] = useState('')
  const [amount, setAmount] = useState('')
  const [financeType, setFinanceType] = useState<Finance['type']>('cash')
  const [monthlyIncome, setMonthlyIncome] = useState('')
  
  // Credit fields
  const [limit, setLimit] = useState('')
  const [debt, setDebt] = useState('')
  const [dueDate, setDueDate] = useState('')

  useEffect(() => {
    if (item) {
      setName(item.name)
      if (type === 'finances') {
        const f = item as Finance
        setAmount(f.amount.toString())
        setFinanceType(f.type)
        setMonthlyIncome(f.monthlyIncome?.toString() || '')
      } else if (type === 'credits') {
        const c = item as Credit
        setLimit(c.limit.toString())
        setDebt(c.debt.toString())
        setDueDate(c.dueDate)
      } else {
        const s = item as Subscription
        setAmount(s.amount.toString())
        setDueDate(s.dueDate)
      }
    } else {
      resetFields()
    }
  }, [item, type, isOpen])

  const resetFields = () => {
    setName('')
    setAmount('')
    setFinanceType('cash')
    setMonthlyIncome('')
    setLimit('')
    setDebt('')
    setDueDate(new Date().toISOString().slice(0, 10))
  }

  const handleSave = () => {
    const id = item?.id || Date.now().toString()
    
    if (type === 'finances') {
      onSave({
        id,
        name: name || 'Без названия',
        amount: parseFloat(amount) || 0,
        type: financeType,
        monthlyIncome: monthlyIncome ? parseFloat(monthlyIncome) : undefined,
      } as Finance)
    } else if (type === 'credits') {
      onSave({
        id,
        name: name || 'Карта',
        limit: parseFloat(limit) || 0,
        debt: parseFloat(debt) || 0,
        dueDate: dueDate || new Date().toISOString().slice(0, 10),
      } as Credit)
    } else {
      onSave({
        id,
        name: name || 'Подписка',
        amount: parseFloat(amount) || 0,
        dueDate: dueDate || new Date().toISOString().slice(0, 10),
      } as Subscription)
    }
    
    onClose()
    resetFields()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm"
        >
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-card rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl safe-area-bottom"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-foreground">{title}</h2>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground"
              >
                <X size={18} />
              </button>
            </div>

            {/* Form */}
            <div className="space-y-4">
              {/* Name */}
              <div>
                <label className="text-sm font-medium text-muted-foreground mb-2 block">
                  Название
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Введите название"
                  className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>

              {/* Finance-specific fields */}
              {type === 'finances' && (
                <>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground mb-2 block">
                      Тип
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {(['cash', 'card', 'investments', 'debt'] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setFinanceType(t)}
                          className={cn(
                            "px-3 py-2 rounded-xl text-sm font-medium transition-all",
                            financeType === t 
                              ? "bg-primary text-primary-foreground" 
                              : "bg-muted text-muted-foreground hover:bg-muted/80"
                          )}
                        >
                          {t === 'cash' ? 'Нал.' : t === 'card' ? 'Карта' : t === 'investments' ? 'Инв.' : 'Долг'}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground mb-2 block">
                      Сумма
                    </label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0"
                      className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                  {financeType === 'investments' && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground mb-2 block">
                        Доход в месяц
                      </label>
                      <input
                        type="number"
                        value={monthlyIncome}
                        onChange={(e) => setMonthlyIncome(e.target.value)}
                        placeholder="0"
                        className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                  )}
                </>
              )}

              {/* Credit-specific fields */}
              {type === 'credits' && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground mb-2 block">
                        Лимит
                      </label>
                      <input
                        type="number"
                        value={limit}
                        onChange={(e) => setLimit(e.target.value)}
                        placeholder="0"
                        className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground mb-2 block">
                        Долг
                      </label>
                      <input
                        type="number"
                        value={debt}
                        onChange={(e) => setDebt(e.target.value)}
                        placeholder="0"
                        className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground mb-2 block">
                      Дата платежа
                    </label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                </>
              )}

              {/* Subscription-specific fields */}
              {type === 'subscriptions' && (
                <>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground mb-2 block">
                      Сумма
                    </label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0"
                      className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground mb-2 block">
                      Дата списания
                    </label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                </>
              )}
            </div>

            {/* Buttons */}
            <div className="flex gap-3 mt-6">
              <button
                onClick={onClose}
                className="flex-1 px-6 py-3.5 rounded-xl bg-muted text-foreground font-semibold transition-colors hover:bg-muted/80"
              >
                Отмена
              </button>
              <button
                onClick={handleSave}
                className="flex-1 px-6 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/30 transition-transform active:scale-[0.98]"
              >
                {isEdit ? 'Сохранить' : 'Добавить'}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
