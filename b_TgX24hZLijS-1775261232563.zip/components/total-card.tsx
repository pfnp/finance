'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import { formatCurrency } from '@/lib/store'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

interface TotalCardProps {
  label: string
  amount: number
  variant?: 'default' | 'success' | 'warning' | 'danger'
  trend?: 'up' | 'down' | 'neutral'
  className?: string
}

export function TotalCard({ 
  label, 
  amount, 
  variant = 'default',
  trend,
  className 
}: TotalCardProps) {
  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex-1 bg-card rounded-3xl p-5 card-shadow",
        className
      )}
    >
      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
        {label}
      </p>
      <div className="flex items-center gap-2">
        <p className={cn(
          "text-xl font-bold tracking-tight",
          variant === 'success' && "text-accent",
          variant === 'danger' && "text-destructive",
          variant === 'warning' && "text-warning",
          variant === 'default' && "text-foreground"
        )}>
          {formatCurrency(amount)}
        </p>
        {trend && (
          <TrendIcon 
            size={16} 
            className={cn(
              trend === 'up' && "text-accent",
              trend === 'down' && "text-destructive",
              trend === 'neutral' && "text-muted-foreground"
            )}
          />
        )}
      </div>
    </motion.div>
  )
}
