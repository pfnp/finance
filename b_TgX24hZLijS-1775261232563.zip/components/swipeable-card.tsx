'use client'

import { ReactNode, useRef, useState } from 'react'
import { motion, useMotionValue, useTransform, PanInfo } from 'framer-motion'
import { Trash2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SwipeableCardProps {
  children: ReactNode
  onDelete: () => void
  onClick: () => void
  className?: string
}

export function SwipeableCard({ children, onDelete, onClick, className }: SwipeableCardProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const constraintsRef = useRef(null)
  const x = useMotionValue(0)
  const deleteOpacity = useTransform(x, [-100, -50, 0], [1, 0.5, 0])
  const deleteScale = useTransform(x, [-100, -50, 0], [1, 0.8, 0.6])

  const handleDragEnd = (_: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (info.offset.x < -80) {
      setIsDeleting(true)
    }
  }

  const handleDelete = () => {
    onDelete()
    setIsDeleting(false)
  }

  const handleClose = () => {
    setIsDeleting(false)
  }

  return (
    <div ref={constraintsRef} className="relative overflow-hidden rounded-2xl">
      {/* Delete button background */}
      <motion.div 
        className="absolute inset-y-0 right-0 w-24 bg-destructive flex items-center justify-center rounded-r-2xl"
        style={{ opacity: deleteOpacity }}
      >
        <motion.div style={{ scale: deleteScale }}>
          <Trash2 className="text-destructive-foreground" size={24} />
        </motion.div>
      </motion.div>

      {/* Main card */}
      <motion.div
        drag="x"
        dragConstraints={{ left: -100, right: 0 }}
        dragElastic={0.1}
        onDragEnd={handleDragEnd}
        animate={{ x: isDeleting ? -100 : 0 }}
        style={{ x }}
        onClick={() => {
          if (!isDeleting) onClick()
        }}
        className={cn(
          "relative bg-card rounded-2xl p-4 card-shadow cursor-pointer active:scale-[0.98] transition-transform",
          className
        )}
      >
        {children}
      </motion.div>

      {/* Delete confirmation overlay */}
      {isDeleting && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-y-0 right-0 w-24 flex items-center justify-center gap-2"
        >
          <button
            onClick={handleDelete}
            className="w-12 h-12 bg-destructive rounded-full flex items-center justify-center text-destructive-foreground shadow-lg"
          >
            <Trash2 size={20} />
          </button>
          <button
            onClick={handleClose}
            className="absolute -left-10 top-1/2 -translate-y-1/2 w-8 h-8 bg-muted rounded-full flex items-center justify-center text-muted-foreground text-sm"
          >
            ✕
          </button>
        </motion.div>
      )}
    </div>
  )
}
