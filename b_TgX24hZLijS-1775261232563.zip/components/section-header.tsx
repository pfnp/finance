'use client'

import { useTheme } from './theme-provider'
import { Plus, Sun, Moon } from 'lucide-react'
import { motion } from 'framer-motion'

interface SectionHeaderProps {
  title: string
  onAdd: () => void
}

export function SectionHeader({ title, onAdd }: SectionHeaderProps) {
  const { theme, toggleTheme } = useTheme()

  return (
    <header className="flex items-center justify-between mb-6">
      <motion.button
        whileTap={{ scale: 0.92 }}
        onClick={toggleTheme}
        className="w-11 h-11 rounded-full bg-card card-shadow flex items-center justify-center text-foreground transition-colors"
        aria-label="Переключить тему"
      >
        {theme === 'light' ? (
          <Moon size={20} strokeWidth={2} />
        ) : (
          <Sun size={20} strokeWidth={2} />
        )}
      </motion.button>

      <h1 className="text-2xl font-bold tracking-tight text-foreground">
        {title}
      </h1>

      <motion.button
        whileTap={{ scale: 0.92 }}
        onClick={onAdd}
        className="w-11 h-11 rounded-full bg-primary flex items-center justify-center text-primary-foreground shadow-lg shadow-primary/30"
        aria-label="Добавить"
      >
        <Plus size={22} strokeWidth={2.5} />
      </motion.button>
    </header>
  )
}
