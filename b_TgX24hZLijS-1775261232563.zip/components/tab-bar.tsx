'use client'

import { TabType } from '@/lib/types'
import { Wallet, CreditCard, Receipt } from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'

interface TabBarProps {
  activeTab: TabType
  onTabChange: (tab: TabType) => void
}

const tabs: { id: TabType; label: string; icon: typeof Wallet }[] = [
  { id: 'subscriptions', label: 'Расходы', icon: Receipt },
  { id: 'finances', label: 'Финансы', icon: Wallet },
  { id: 'credits', label: 'Кредитки', icon: CreditCard },
]

export function TabBar({ activeTab, onTabChange }: TabBarProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass bg-tab-bar-bg border-t border-tab-bar-border safe-area-bottom">
      <div className="flex justify-around items-center px-4 py-2 max-w-lg mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={cn(
                "relative flex flex-col items-center gap-1 px-6 py-2 rounded-2xl transition-all duration-300",
                isActive 
                  ? "text-primary" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-primary/10 rounded-2xl"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
              <Icon 
                className={cn(
                  "relative z-10 transition-transform duration-300",
                  isActive ? "scale-110" : "scale-100"
                )} 
                size={24} 
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span className="relative z-10 text-[11px] font-medium tracking-tight">
                {tab.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
