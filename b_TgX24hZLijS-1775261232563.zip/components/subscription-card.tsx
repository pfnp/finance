'use client'

import { Subscription } from '@/lib/types'
import { formatCurrency, daysUntilDate } from '@/lib/store'
import { SwipeableCard } from './swipeable-card'
import { Receipt, Calendar } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SubscriptionCardProps {
  subscription: Subscription
  onEdit: () => void
  onDelete: () => void
}

export function SubscriptionCard({ subscription, onEdit, onDelete }: SubscriptionCardProps) {
  const daysLeft = daysUntilDate(subscription.dueDate)
  const isUrgent = daysLeft <= 3 && daysLeft >= 0
  
  return (
    <SwipeableCard onDelete={onDelete} onClick={onEdit}>
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-12 h-12 rounded-2xl flex items-center justify-center",
          isUrgent ? "bg-warning/10 text-warning" : "bg-chart-3/10 text-chart-3"
        )}>
          <Receipt size={22} />
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground truncate">
            {subscription.name}
          </h3>
          <div className={cn(
            "flex items-center gap-1 text-xs mt-1",
            isUrgent ? "text-warning" : "text-muted-foreground"
          )}>
            <Calendar size={12} />
            {daysLeft === 0 ? 'Оплата сегодня' :
             daysLeft === 1 ? 'Завтра' :
             daysLeft < 0 ? `${Math.abs(daysLeft)} дн. назад` :
             `Через ${daysLeft} дн.`}
          </div>
        </div>
        
        <p className="text-lg font-bold text-foreground tabular-nums">
          {formatCurrency(subscription.amount)}
        </p>
      </div>
    </SwipeableCard>
  )
}
