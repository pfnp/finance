'use client'

import { Finance, Credit, Subscription } from './types'

const STORAGE_KEYS = {
  finances: 'finance_app_data',
  credits: 'credits_app_data',
  subscriptions: 'subscriptions_app_data',
  theme: 'app_theme',
}

function getFutureDate(days: number): string {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString().slice(0, 10)
}

function getFutureDateForSub(dayOfMonth: number): string {
  const today = new Date()
  let target = new Date(today.getFullYear(), today.getMonth(), dayOfMonth)
  if (target < today) {
    target = new Date(today.getFullYear(), today.getMonth() + 1, dayOfMonth)
  }
  return target.toISOString().slice(0, 10)
}

const defaultFinances: Finance[] = [
  { id: '1', name: 'Наличные', amount: 15000, type: 'cash' },
  { id: '2', name: 'Акции', amount: 50000, type: 'investments', monthlyIncome: 1200 },
  { id: '3', name: 'Друг долг', amount: 3000, type: 'debt' },
]

const defaultCredits: Credit[] = [
  { id: '1', name: 'Тинькофф', limit: 100000, debt: 25000, dueDate: getFutureDate(5) },
  { id: '2', name: 'СберКарта', limit: 70000, debt: 12000, dueDate: getFutureDate(2) },
]

const defaultSubscriptions: Subscription[] = [
  { id: '1', name: 'Netflix', amount: 799, dueDate: getFutureDateForSub(15) },
  { id: '2', name: 'YouTube Premium', amount: 399, dueDate: getFutureDateForSub(8) },
]

export function loadFinances(): Finance[] {
  if (typeof window === 'undefined') return defaultFinances
  const saved = localStorage.getItem(STORAGE_KEYS.finances)
  if (saved) {
    try {
      return JSON.parse(saved)
    } catch {
      return defaultFinances
    }
  }
  return defaultFinances
}

export function loadCredits(): Credit[] {
  if (typeof window === 'undefined') return defaultCredits
  const saved = localStorage.getItem(STORAGE_KEYS.credits)
  if (saved) {
    try {
      return JSON.parse(saved)
    } catch {
      return defaultCredits
    }
  }
  return defaultCredits
}

export function loadSubscriptions(): Subscription[] {
  if (typeof window === 'undefined') return defaultSubscriptions
  const saved = localStorage.getItem(STORAGE_KEYS.subscriptions)
  if (saved) {
    try {
      return JSON.parse(saved)
    } catch {
      return defaultSubscriptions
    }
  }
  return defaultSubscriptions
}

export function saveFinances(finances: Finance[]) {
  if (typeof window === 'undefined') return
  localStorage.setItem(STORAGE_KEYS.finances, JSON.stringify(finances))
}

export function saveCredits(credits: Credit[]) {
  if (typeof window === 'undefined') return
  localStorage.setItem(STORAGE_KEYS.credits, JSON.stringify(credits))
}

export function saveSubscriptions(subscriptions: Subscription[]) {
  if (typeof window === 'undefined') return
  localStorage.setItem(STORAGE_KEYS.subscriptions, JSON.stringify(subscriptions))
}

export function loadTheme(): 'light' | 'dark' {
  if (typeof window === 'undefined') return 'light'
  const saved = localStorage.getItem(STORAGE_KEYS.theme)
  if (saved === 'dark') return 'dark'
  if (saved === 'light') return 'light'
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

export function saveTheme(theme: 'light' | 'dark') {
  if (typeof window === 'undefined') return
  localStorage.setItem(STORAGE_KEYS.theme, theme)
}

export function sortFinances(arr: Finance[]): Finance[] {
  const order = { investments: 1, card: 2, cash: 3, debt: 4 }
  return [...arr].sort((a, b) => {
    if (order[a.type] !== order[b.type]) return order[a.type] - order[b.type]
    return b.amount - a.amount
  })
}

export function sortCredits(arr: Credit[]): Credit[] {
  return [...arr].sort((a, b) => {
    const daysA = daysUntilDate(a.dueDate)
    const daysB = daysUntilDate(b.dueDate)
    if (daysA < 0 && daysB >= 0) return -1
    if (daysB < 0 && daysA >= 0) return 1
    return daysA - daysB
  })
}

export function sortSubscriptions(arr: Subscription[]): Subscription[] {
  return [...arr].sort((a, b) => daysUntilDate(a.dueDate) - daysUntilDate(b.dueDate))
}

export function daysUntilDate(dateStr: string): number {
  const target = new Date(dateStr)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return Math.ceil((target.getTime() - today.getTime()) / (1000 * 3600 * 24))
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    maximumFractionDigits: 0,
  }).format(amount)
}

export function getFinanceTypeLabel(type: Finance['type']): string {
  const labels: Record<Finance['type'], string> = {
    cash: 'Наличные',
    card: 'Карта',
    investments: 'Инвестиции',
    debt: 'Долг',
  }
  return labels[type]
}

export function getFinanceTypeIcon(type: Finance['type']): string {
  const icons: Record<Finance['type'], string> = {
    cash: '💵',
    card: '💳',
    investments: '📈',
    debt: '📋',
  }
  return icons[type]
}
