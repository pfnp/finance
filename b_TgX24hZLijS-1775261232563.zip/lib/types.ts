export interface Finance {
  id: string
  name: string
  amount: number
  type: 'cash' | 'card' | 'investments' | 'debt'
  monthlyIncome?: number
}

export interface Credit {
  id: string
  name: string
  limit: number
  debt: number
  dueDate: string
}

export interface Subscription {
  id: string
  name: string
  amount: number
  dueDate: string
}

export type TabType = 'finances' | 'credits' | 'subscriptions'

export interface ModalState {
  isOpen: boolean
  mode: 'add' | 'edit'
  type: TabType
  item?: Finance | Credit | Subscription
}
